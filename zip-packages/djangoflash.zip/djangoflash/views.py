# -*- coding: utf-8 -*-

"""Django-Flash doesn't provide any Django views.
"""
